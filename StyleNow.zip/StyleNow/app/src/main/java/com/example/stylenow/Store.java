package com.example.stylenow;

public class Store {
    public int id;
    public String name;
    public String logo;

    public Store(int id, String name, String logo) {
        this.id = id;
        this.name = name;
        this.logo = logo;
    }
}
